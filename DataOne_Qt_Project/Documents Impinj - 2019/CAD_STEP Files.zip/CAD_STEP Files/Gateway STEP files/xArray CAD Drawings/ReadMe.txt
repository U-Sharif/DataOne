Included 3 files:

xArray Mounting Plate.pdf � Mechanical Drawing of Mounting Plate
xArray Mounting Plate.step � Solid Model of Mounting Plate
xArray.step � Solid Model of xArray Shell, does not include any electronics or ground plane
